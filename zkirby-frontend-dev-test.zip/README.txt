I created this page using a Node/Gulp environment. Attached you will find the /app folder which contains all of my source files (Sass + Compass for CSS pre-processing, Slim for HTML templating) and the /build folder which contains the finished product. I did not include the /node_modules folder in this ZIP due to the size of the files. 

Only 2 javascript libraries were used: jQuery and jQuery Fullpage. I used jQuery Fullpage for the hero slider because it is widely used, light-weight and responsive. I used CSS3 transitions to slide the content in to view. These animations will work in all modern browsers. 

To see the finished product, launch /build/index.html. The page was tested in the lastest builds of Chrome, Firefox and Safari along with IE9-11, and it is fully responsive.